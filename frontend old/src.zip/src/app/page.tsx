"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

const API_URL = "http://127.0.0.1:8000";

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleLogin(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (loading) return;

    setError("");

    if (!email.trim() || !password) {
      setError("Please enter your email and password.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          password: password,
        }),
      });

      const data = await response.json();

      console.log("LOGIN RESPONSE:", data);

      if (!response.ok) {
        throw new Error(
          data?.detail || "Login failed."
        );
      }

      if (!data?.access_token) {
        throw new Error(
          "Login succeeded but no access token was returned."
        );
      }

      // Save current user's session
      localStorage.setItem(
        "drishtiai_token",
        data.access_token
      );

      if (data.user) {
        localStorage.setItem(
          "drishtiai_user",
          JSON.stringify(data.user)
        );

        const userName =
          data.user.name ||
          data.user.full_name ||
          data.user.username ||
          data.user.email ||
          "there";

        localStorage.setItem(
          "drishtiai_user_name",
          userName
        );
      }

      // Go to dashboard without full page reload
      router.push("/dashboard");

    } catch (err) {
      console.error("LOGIN ERROR:", err);

      setError(
        err instanceof Error
          ? err.message
          : "Unable to sign in."
      );

      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex items-center justify-center px-6">

      <div className="w-full max-w-md">

        <div className="text-center mb-8">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-[#0F766E] text-xl font-bold text-white">
            D
          </div>

          <h1 className="mt-4 text-3xl font-bold">
            DrishtiAI
          </h1>

          <p className="mt-2 text-sm text-[#64748B]">
            Retinal Intelligence Platform
          </p>
        </div>

        <div className="rounded-2xl border border-[#E2E8F0] bg-white p-8 shadow-sm">

          <h2 className="text-2xl font-semibold">
            Sign in
          </h2>

          <p className="mt-2 text-sm text-[#64748B]">
            Access your DrishtiAI dashboard.
          </p>

          <form
            onSubmit={handleLogin}
            className="mt-7 space-y-5"
          >

            <div>
              <label
                htmlFor="email"
                className="mb-2 block text-sm font-medium"
              >
                Email address
              </label>

              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
                placeholder="you@example.com"
                autoComplete="email"
                className="w-full rounded-lg border border-[#CBD5E1] bg-white px-4 py-3 text-sm outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/10"
              />
            </div>

            <div>
              <label
                htmlFor="password"
                className="mb-2 block text-sm font-medium"
              >
                Password
              </label>

              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) =>
                  setPassword(e.target.value)
                }
                placeholder="Enter your password"
                autoComplete="current-password"
                className="w-full rounded-lg border border-[#CBD5E1] bg-white px-4 py-3 text-sm outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/10"
              />
            </div>

            {error && (
              <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-[#0F766E] px-5 py-3.5 text-sm font-semibold text-white hover:bg-[#115E59] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading
                ? "Signing in..."
                : "Sign in"}
            </button>

          </form>

          <p className="mt-6 text-center text-xs text-[#94A3B8]">
            DrishtiAI is an AI-assisted screening
            platform and does not replace professional
            medical diagnosis.
          </p>

        </div>

      </div>

    </main>
  );
}